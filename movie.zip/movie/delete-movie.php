<?php
include_once "classes/DB.php";

use Classes\DB;

if(isset($_GET['movie-id'])) {
    $db = new DB("localhost", "root", "", "movie", "3306");

    $delete = $db->deleteMovie($_GET['movie-id']);

    if($delete) {
        header("Location: review.php?id=".$_GET['movie-id']);
    } else {
        echo "Film neodstraneny";
    }
} else {
    header("Location: index.php");
}

