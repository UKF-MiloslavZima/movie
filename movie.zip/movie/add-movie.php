<?php
include_once "classes/DB.php";

use Classes\DB;

if(isset($_POST['submit'])) {
    $db = new DB("localhost", "root", "", "movie", "3306");

    $movieId = $_POST['movie_id'];
    $title = $_POST['title'];
    $perex = $_POST['perex'];
    $content = $_POST['content'];
    $image = $_POST['image'];

    $insert = $db->insertMovie($title, $perex, $content, $image);

    if($insert) {
        header("Location: review.php");
    } else {
        echo "Film neulozeny";
    }
} else {
    echo "Formular neodoslany";
}

