<!DOCTYPE html>
<html lang="en">
<?php include_once "parts/header.php";

if(isset($db)) {
    $movies = $db->getMovies();
} else {
    $db = new stdClass();
    $movies = [];
}
?>


	<body>
		

		<div id="site-content">
            <?php include_once "parts/nav.php"; ?>
			<main class="main-content">
				<div class="container">
					<div class="page">
						<div class="breadcrumbs">
							<a href="index.php">Home</a>
							<span>Movie Review</span>
						</div>

						<div class="filters">
							<select name="#" id="#" placeholder="Choose Category">
								<option value="#">Action</option>
								<option value="#">Drama</option>
								<option value="#">Fantasy</option>
								<option value="#">Horror</option>
								<option value="#">Adventure</option>
							</select>
							<select name="#" id="#">
								<option value="#">2012</option>
								<option value="#">2013</option>
								<option value="#">2014</option>
							</select>
						</div>
						<div class="movie-list">
                            <?php
                            $i = 0;
                            foreach ($movies as $movie) {
                                include "parts/movie.php";
                                $i++;
                            }
                            ?>

						</div> <!-- .movie-list -->

                        <div class="contact-form">
                            <form action="add-movie.php" method="post">
                            <input type="text" name="title" placeholder="Title">
                            <input type="text" name="perex" placeholder="Perex">
                            <textarea name="content" placeholder="Content"></textarea>
                            <input type="text" name="image" placeholder="Image">
                            <input type="submit" value="Insert movie">
                            </form>
                        </div>

						<div class="pagination">
							<a href="#" class="page-number prev"><i class="fa fa-angle-left"></i></a>
							<span class="page-number current">1</span>
							<a href="#" class="page-number">2</a>
							<a href="#" class="page-number">3</a>
							<a href="#" class="page-number">4</a>
							<a href="#" class="page-number">5</a>
							<a href="#" class="page-number next"><i class="fa fa-angle-right"></i></a>
						</div>
					</div>
				</div> <!-- .container -->
			</main>
            <?php include_once "parts/footer.php"; ?>
		</div>
		<!-- Default snippet for navigation -->



        <?php include_once "parts/script.php"; ?>
		
	</body>

</html>