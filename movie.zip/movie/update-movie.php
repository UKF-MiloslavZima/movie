<?php

include_once "classes/DB.php";

use Classes\DB;

$db = new DB("localhost", "root", "", "movie", "3306");

if(isset($_GET['movie-id'])) {
    $movie = $db->getMovie($_GET['movie-id']);
}

if(isset($_POST['submit'])) {
    $update = $db->updateMovie($_POST['movie-id'], $_POST['title'], $_POST['perex'], $_POST['content'], $_POST['image'] );

    if($update) {
        header("Location: review.php?id=".$_POST['movie-id']);
    } else {
        echo "Chyba";
    }
} else {
    ?>

    <form action="" method="post">
        Title:<br>
        <input type="text" name="title" value="<?php echo $movie['title']; ?>"><br>
        Perex:<br>
        <textarea name="perex" rows="6"><?php echo $movie['perex']; ?></textarea><br>
        Content:<br>
        <textarea name="content" rows="6"><?php echo $movie['content']; ?></textarea><br>
        Image:<br>
        <input type="text" name="image" value="<?php echo $movie['image']; ?>"><br>
        <input type="hidden" name="movie-id" value="<?php echo $_GET['movie-id']; ?>">
        <input type="submit" name="submit" value="Submit">
    </form>


    <?php
}