<?php
if(!isset($movie)) {
    $movie = [];
}
if(!isset($i)) {
    $i = 0;
}
if(!isset($db)) {
    $db = new stdClass();
}
?>


<div class="movie">
    <figure class="movie-poster"><img src="<?php echo $movie['image']; ?>" alt="#"></figure>
    <div class="movie-title"><a href="single.php?id=<?php echo $movie['id']; ?>"><?php echo $movie['title']; ?></a></div>
    <p><?php echo $movie['perex']; ?></p>
    <a href="delete-movie.php?movie-id=<?php echo $movie['id'];?>">Delete</a>
    <a href="update-movie.php?movie-id=<?php echo $movie['id'];?>">Update</a>
</div>


