<?php

namespace Classes;

class DB
{
    private $host;
    private $username;
    private $pass;
    private $dbName;
    private $port;

    private $connection;

    public function __construct($host, $username, $pass, $dbName, $port)
    {
        $this->host = $host;
        $this->username = $username;
        $this->pass = $pass;
        $this->dbName = $dbName;
        $this->port = $port;

        try {
            $this->connection = new \PDO("mysql:host=".$this->host.";port=".$this->port.";dbname=".$this->dbName, $this->username, $this->pass);
            // set the PDO error mode to exception
            $this->connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        } catch(\PDOException $e) {
            echo "Connection failed: " . $e->getMessage();
        }
    }

    public function getMenu()
    {
        $sql = "SELECT * FROM menu";
        $stm = $this->connection->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll(\PDO::FETCH_ASSOC);

        return $result;
    }

    public function getMovies()
    {
        $sql = "SELECT m.id, m.title, m.perex, m.image
                FROM `movies` AS m";
        $stm = $this->connection->prepare($sql);
        $stm->execute();
        $result = $stm->fetchAll(\PDO::FETCH_ASSOC);

        return $result;
    }

    public function getMovie($movieId)
    {
        $sql = "SELECT m.id, m.title, m.content, m.image
                FROM `movies` AS m
                WHERE m.id = :movie_id";
        $stm = $this->connection->prepare($sql);
        $stm->bindValue(':movie_id', $movieId);
        $stm->execute();
        $result = $stm->fetch(\PDO::FETCH_ASSOC);

        return $result;
    }

    public function deleteMovie($movieId)
    {
        $sql = "DELETE FROM movies WHERE id = :id";
        $stm = $this->connection->prepare($sql);
        $stm->bindValue(":id", $movieId);
        $result = $stm->execute();

        return $result;
    }

    public function insertMovie($title, $perex, $content, $image)
    {
        $sql = "INSERT INTO movies(title, perex, content, image) VALUE(:title, :perex, :content, :image)";
        $stm = $this->connection->prepare($sql);
        $stm->bindValue(':title', $title);
        $stm->bindValue(':perex', $perex);
        $stm->bindValue(':content', $content);
        $stm->bindValue(':image', $image);
        $result = $stm->execute();

        return $result;

    }

    public function updateMovie($movieId, $title, $perex, $content, $image)
    {
        $sql = "UPDATE movies SET title = '".$title."', content = '".$content."', perex = '".$perex."', image = '".$image."' WHERE id = '".$movieId."'";
        $stm = $this->connection->prepare($sql);
        $result = $stm->execute();

        return $result;
    }
}